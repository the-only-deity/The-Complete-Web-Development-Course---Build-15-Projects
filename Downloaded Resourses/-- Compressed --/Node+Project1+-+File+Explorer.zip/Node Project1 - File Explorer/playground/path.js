const path = require('path');

console.log(path.join('Node', 'Project1'));

console.log(path.normalize('../../Node/../Built in Modules fs'));

console.log(path.resolve('../../Node/../Built in Modules fs'));